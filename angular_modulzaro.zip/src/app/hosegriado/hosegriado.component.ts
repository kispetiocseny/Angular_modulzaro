import { Component } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrls: ['./hosegriado.component.css']
})
export class HosegriadoComponent {
  szam1!: number;
  szam2!: number;
  szam3!: number;

  eredmenyek: string[] = [];

  aktualisRiadoSzint(): number {
    let ertek = 0;
    if (this.szam1 && this.szam2 && this.szam3) {
      if (this.szam1 >= 30 && this.szam2 >= 30 && this.szam3 >= 30) {
        ertek = 3;
      } else if (this.szam1 >= 27 && this.szam2 >= 27 && this.szam3 >= 27) {
        ertek = 2;
      } else if (this.szam1 >= 25 || this.szam2 >= 25 || this.szam3 >= 25) {
        ertek = 1;
      }
      else {
        ertek = 0;
      }
    }
    return ertek;
  }

  saveData() {
    if (this.szam1 && this.szam2 && this.szam3) {
      const riadoSzint = this.aktualisRiadoSzint();
      const log = `${this.szam1}, ${this.szam2} és ${this.szam3} esetén ${riadoSzint}. szintű hőségriadó volt elrendelve`;
      this.eredmenyek.push(log);
    }
  }
}
